app.controller("page_one",page_one);
function page_one($scope) {
    $scope.var_one = "I am from page one controller !";
}