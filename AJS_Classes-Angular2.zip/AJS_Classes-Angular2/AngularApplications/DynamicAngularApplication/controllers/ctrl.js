/*
app.controller("ctrl", function ($scope) {
    $scope.var_one = "Data From DataBase Soon....";
});*/


app.controller("ctrl", ctrl);
function ctrl($scope){
    $scope.var_one = "Data From DataBase Soon...";
}
