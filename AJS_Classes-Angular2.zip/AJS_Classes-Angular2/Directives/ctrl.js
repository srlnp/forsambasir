app.controller("ctrl",ctrl);
function ctrl($scope) {
    $scope.array = [
        {'id':1,'name':'AngularJS'},
        {'id':2,'name':'Angular2'},
        {'id':3,'name':'reactJS'},
        {'id':4,'name':'NodeJS'},
        {'id':5,'name':'mongodb'}
    ];

}