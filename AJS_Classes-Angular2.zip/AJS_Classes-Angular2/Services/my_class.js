function my_class(arg1,arg2,arg3) {
    this.my_fun = function () {
        return arg1+"<==>"+arg2+"<==>"+arg3;
    };
};