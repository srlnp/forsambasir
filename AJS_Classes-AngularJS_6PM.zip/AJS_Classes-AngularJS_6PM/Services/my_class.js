function my_class() {
    this.my_fun = function () {
        return "I am from external script file !";
    };
};