app.controller("summary",summary);
function summary($scope){
	$scope.summary="Results Soon...!";
}