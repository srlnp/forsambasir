app.directive("elemType",elemType);

function elemType() {
    return{
        template:"<div class='jumbotron'><b style='color: green'>Welcome to Element Type Custom Directive !</b></div>"
    }
}