function one(){
    this.x = 1;
    this.y = 2;
}
