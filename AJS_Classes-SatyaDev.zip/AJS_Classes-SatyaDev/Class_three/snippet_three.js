var obj1 = new one();
// document.write(obj1.x+""+ obj1.y);

var obj2 = new two(obj1);
var my_obj = obj2.a;
document.write(my_obj.x+"...."+my_obj.y);
