function two(data) {
    this.a = data;
}