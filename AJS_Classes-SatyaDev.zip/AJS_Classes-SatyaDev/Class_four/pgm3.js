var clas3 =function (data1, data2){
    this.fun5=function (){
        return data1.fun1();
    }
    this.fun6=function (){
        return data2.fun1();
    }
}