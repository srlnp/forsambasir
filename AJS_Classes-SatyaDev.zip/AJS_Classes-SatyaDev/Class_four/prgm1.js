function clas1(){
    this.fun1 = function () {
        return "i am from function 1";
    }


    this.fun2 = function () {
        return "i am from function 2";
    }
}