var clas2 =function (){
    this.fun1=function (){
        return "i am from fun three";
    }
    this.fun2=function (){
        return "i am from fun four";
    }
}