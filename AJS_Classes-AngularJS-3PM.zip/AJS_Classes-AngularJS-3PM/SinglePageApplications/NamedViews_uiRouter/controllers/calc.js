app.controller("calc",calc);
calc.$inject=["$scope"];
function calc($scope) {
    $scope.calc = "calculations Soon....";
}