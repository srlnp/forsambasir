function my_fun() {
    alert("Welcome to my_fun");
}