function my_function() {
    alert("Welcome to my_function");
}