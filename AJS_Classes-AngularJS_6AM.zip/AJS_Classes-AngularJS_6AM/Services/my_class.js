var my_class = function (arg1) {
    this.my_fun = function () {
      return arg1;
    };
};