app.controller("ctrl",ctrl);
function ctrl($scope) {
    $scope.array = [{'s_id':1,'s_name':'Neeraja'},
        {'s_id':2,'s_name':'kundana'},
        {'s_id':3,'s_name':'Naresh'},
        {'s_id':4,'s_name':'Balaji'},
        {'s_id':5,'s_name':'Teja'}];
}