app.controller("ctrl",ctrl);
function ctrl($scope) {
    $scope.sub_one = "AngularJS";
    $scope.sub_two = "NodeJS";
    $scope.sub_three = "MongoDB";
}