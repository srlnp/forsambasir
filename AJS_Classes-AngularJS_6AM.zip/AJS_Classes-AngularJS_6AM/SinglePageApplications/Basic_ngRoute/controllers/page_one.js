﻿app.controller("page_one", page_one);
function page_one($scope) {
    $scope.var_one = "data from DB soon";
}
    
