app.controller("ctrl",ctrl);
		function ctrl($scope){
			$scope.array = [
				{'id':1,'name':'Hello_1','age':20},
				{'id':2,'name':'Hello_2','age':22},
				{'id':3,'name':'Hello_3','age':24},
				{'id':4,'name':'Hello_4','age':26},
				{'id':5,'name':'Hello_5','age':28}
			];
		}