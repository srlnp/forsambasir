function fun_two() {
    alert("Welcome to fun two");
}