function fun_one() {
    alert("Welcome to fun one !");
}