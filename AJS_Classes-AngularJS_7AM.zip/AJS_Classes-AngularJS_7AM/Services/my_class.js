function my_class() {
    this.my_fun = function () {
        return "I am from External JS Class !";
    };
};