app.controller("calcController",calcController);
function calcController($scope) {
    $scope.calc = "Calculations Soon....!";
}