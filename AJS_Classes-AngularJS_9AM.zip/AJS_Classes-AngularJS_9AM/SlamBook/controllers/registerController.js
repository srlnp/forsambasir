(function () {
    "use strict";
    app.controller("registerController",registerController);
    registerController.$inject=["$scope"];
    function registerController($scope) {
        $scope.register="Registaration Page Soon....";
    }

})();