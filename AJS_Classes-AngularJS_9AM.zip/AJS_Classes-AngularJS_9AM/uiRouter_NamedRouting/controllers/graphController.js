app.controller("graphController",graphController);
graphController.$inject=["$scope"];
function graphController($scope) {
    $scope.var_four="Sub View Two";
}