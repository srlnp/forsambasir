app.controller("calculationsController",calculationsController);
calculationsController.$inject=["$scope"];
function calculationsController($scope) {
    $scope.var_three="Sub View One";
}